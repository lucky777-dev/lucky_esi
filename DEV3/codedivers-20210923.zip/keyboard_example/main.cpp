#include "keyboardAndStringConvert/keyboard.hpp"

#include <iostream>
#include <exception>

// lecture au clavier avec les fonctions nvs::lineFromKbd

int main()
{
    using namespace std;
    using namespace nvs;

    unsigned u { 7 };
    cout << u << endl;

    cout << "valeur pour u : ";
    try
    {
        nvs::lineFromKbd(u);
    }
    catch (const exception & e)
    {
        cout << "problème : " << e.what() << endl;
    }
    cout << u << endl;

    // probablement mieux car u pas modifié si problème de lecture :
    u = 7;
    cout << '\n' << u << endl;

    cout << "valeur pour u : ";
    try
    {
        u = nvs::lineFromKbd<unsigned>();
    }
    catch (const exception & e)
    {
        cout << "problème : " << e.what() << endl;
    }
    cout << u << endl;

    // ------------------------------------------------

    int i { -1 };   // pas prendre i dans [0, 8] !
    cout << "\nExemple de lecture fiabilisée" << endl;
    do
    {
        try
        {
            cout << "valeur pour i (dans [0, 8]) : ";
            i = lineFromKbd<int>();
        }
        catch (const exception & e)
        {
            cout << "problème : " << e.what() << endl;
        }
    }
    while (i < 0 || i > 8);
    cout << "i : " << i << endl;

    // --- cin : c'est beaucoup plus compliqué -------

    i = -1;
    cout << "\nExemple de lecture _non_ fiabilisée" << endl;
    do
    {
        cout << "valeur pour i (dans [0, 8]) : ";
        cin >> i;
    }
    while (i < 0 || i > 8);
    cout << "i : " << i << endl;
}

