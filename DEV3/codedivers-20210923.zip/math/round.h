/*! \file round.h
 *
 * \brief Implémentation d'une fonction d'arrondie à un nombre
 *         voulu de chiffres après la virgule.
 *
 * \author nvs
 * \date 2014/01/28
 *
 */

#ifndef ROUND_H
#define ROUND_H

#include <cmath>

namespace nvs
{
inline long double round(const long double & val, unsigned decimal = 0)
{
    long double factor = std::pow(10, decimal);
    return std::round(val * factor) / factor;
}
}

#endif // ROUND_H
