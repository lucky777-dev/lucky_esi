var files =
[
    [ "observer.h", "a00003.html", [
      [ "Observer", "a00001.html", "a00001" ]
    ] ],
    [ "subject.cpp", "a00004.html", null ],
    [ "subject.h", "a00005.html", [
      [ "Subject", "a00002.html", "a00002" ]
    ] ]
];