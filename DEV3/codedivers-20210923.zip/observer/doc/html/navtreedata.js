var NAVTREE =
[
  [ "Observer", "index.html", [
    [ "Modèle de conception Observateur", "index.html", null ],
    [ "Espaces de nommage", null, [
      [ "Liste des espaces de nommage", "namespaces.html", "namespaces" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Liste des classes", "annotated.html", "annotated_dup" ],
      [ "Membres de classe", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Fonctions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"a00001.html"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';