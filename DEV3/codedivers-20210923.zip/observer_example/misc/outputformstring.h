/*!
 * \file outputformstring.h
 * \brief Définition de l'énumération fortement typée
 *        nvs::OutputFormString.
 */
#ifndef OUTPUTFORMSTRING_H
#define OUTPUTFORMSTRING_H

/*!
 * \brief Espace de nom de Nicolas Vansteenkiste.
 */
namespace nvs
{

/*!
 * \brief Énumération fortement typée pour requérir un format
 *        de chaîne de caractère _long_ ou _court_.
 */
enum class OutputFormString
{
    /*! Pour demander un formatage court. */
    SHORT,
    /*! Pour demander un formatage long. */
    LONG
};

}

#endif // OUTPUTFORMSTRING_H

