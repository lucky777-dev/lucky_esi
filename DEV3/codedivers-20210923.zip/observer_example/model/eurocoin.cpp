/*!
 * \file eurocoin.cpp
 * \brief Implémentation de la classe money::EuroCoin.
 */
#include "eurocoin.h"

#include <set>
#include <stdexcept>

using namespace std;

namespace money
{

void EuroCoin::validateValue(unsigned value)
{
    static const set<unsigned> values { 1, 2, 5, 10, 20, 50, 100, 200 };

    if (values.count(value) == 0)
    {
        throw invalid_argument { "value : " + std::to_string(value)
                                 + " : invalid for a " + longName() +
                                 " coin" };
    }
}

} // namespace money
