/*!
 * \file side.cpp
 * \brief Implémentation de l'énumération fortement typée
 *        money::Side et de fonctions l'utilisant.
 */
#include "side.h"

#include <ostream>
#include <string>

namespace money
{

std::ostream & operator<<(std::ostream & out, Side side)
{
    return out << to_string(side);
}

std::string to_string(Side side, nvs::OutputFormString form)
{
    using namespace nvs;
    std::string result;
    switch (side)
    {
        case Side::UNKNOWN:
            result = form == OutputFormString::SHORT ? "U" : "UNKNOWN";
            break;
        case Side::HEAD:
            result = form == OutputFormString::SHORT ? "H" : "HEAD";
            break;
        case Side::TAIL:
            result = form == OutputFormString::SHORT ? "T" : "TAIL";
            break;
        default:
            result = form == OutputFormString::SHORT ? "?" : "???";
            break;
    }
    return result;
}

} // namespace money



