/*!
 * \file side.h
 * \brief Définition de l'énumération fortement typée
 *        money::Side et de fonctions l'utilisant.
 */
#ifndef SIDE_H
#define SIDE_H

#include "../misc/outputformstring.h"

#include <ostream>
#include <string>

/*!
 * \brief Espace de nom des pièces de monnaies et autres petites choses.
 */
namespace money
{

/*!
 * \brief Énumération fortement typée pour représenter une face
 *        (un côté) d'une pièce de monnaie.
 */
enum class Side
{
    /*! Pour représenter la non connaissance de la face de la pièce
     *  de monnaie. */
    UNKNOWN,
    /*! Pour représenter le côté face. */
    HEAD,
    /*! Pour représenter le côté pile. */
    TAIL,
};

/*!
 * \brief Opérateur d'injection dans un flux en sortie.
 *
 * Cet opérateur d'injection utilise la conversion courte
 * d'une face d'une pièce de monnaie en `std::string` obtenue par
 * to_string(Face, OutputFormString).
 *
 * \param out le flux en sortie dans lequel l'injection a lieu.
 * \param side la face à injecter.
 *
 * \return le flux après l'injection.
 */
std::ostream & operator<<(std::ostream & out, Side side);

/*!
 * \brief Conversion en chaîne de caractères.
 *
 * Fonction de conversion d'une face d'une pièce de monnaie
 * en chaîne de caractères.
 *
 * \param side la face à convertir.
 * \param form pour contrôler la forme longue ou courte de
 *             l'affichage.
 *
 * \return une chaîne de caractères représentant la face de la
 *         pièce de monnaie.
 */
std::string to_string(Side side, nvs::OutputFormString form =
                          nvs::OutputFormString::SHORT);

} // namespace money


#endif // SIDE_H
