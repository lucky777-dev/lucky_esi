/*!
 * \file eurocoin.h
 * \brief Définition de la classe money::EuroCoin.
 */
#ifndef EUROCOIN_H
#define EUROCOIN_H

#include "coin.h"

/*!
 * \brief Espace de nom des pièces de monnaies et autres petites choses.
 */
namespace money
{

/*!
 * \brief Classe représentant les pièces
 *        d'[euro](https://fr.wikipedia.org/wiki/Pi%C3%A8ces_en_euro_destin%C3%A9es_%C3%A0_la_circulation#Description_des_pi.C3.A8ces).
 */
class EuroCoin final : public Coin
{
    /*!
     * \brief Validation de la valeur d'une pièce d'euro.
     *
     * Cette méthode est utilisée par le constructeur d'EuroCoin.
     * Il s'agit de valeurs en centimes. Les valeurs valides sont
     * donc :
     *
     *      1, 2, 5, 10, 20, 50, 100, 200
     *
     * conformément à l'usage actuel.
     *
     * \param value la valeur à valider en _centimes_.
     *
     * \throw std::invalid_argument si `value` n'est pas valide.
     */
    virtual void validateValue(unsigned value) override;

  public:
    /*!
     * \brief Constructeur.
     *
     * À la construction, une pièce de monnaie présente toujours
     * une face inconnue. Le nom long d'une EuroCoin est :
     *
     *      euro
     *
     * tandis que son nom court est :
     *
     *      €
     *
     * La valeur est validée à l'aide de la méthode
     * EuroCoin::validateValue().
     *
     * \param value la valeur initiale exprimée en _centimes_.
     *
     * \see validateValue().
     */
    inline EuroCoin(unsigned value = 100);
};

// implémentation de méthodes inline

EuroCoin::EuroCoin(unsigned value) :
    Coin { "euro", "€", value }
{
    validateValue(this->value());
}

} // namespace money

#endif // EUROCOIN_H
