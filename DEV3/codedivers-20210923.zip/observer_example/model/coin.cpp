/*!
 * \file coin.cpp
 * \brief Implémentation de la classe money::Coin et de fonctions
 *        utilisant ce type.
 */
#include "coin.h"

#include "../random/randomgenerator.hpp"

#include <stdexcept>
#include <string>

namespace money
{
// implémentation de méthodes

// méthodes d'objet

Side money::Coin::flip()
{
    faceUp_ = nvs::random_integer(0, 1) ? Side::HEAD : Side::TAIL;
    notifyObservers();
    return faceUp_;
}

void Coin::setFaceUp(Side face)
{
    if (face != faceUp_)
    {
        faceUp_ = face;
        notifyObservers();
    }
}

std::string Coin::to_string(nvs::OutputFormString form) const
{
    std::string result { '[' };

    result.append(std::to_string(value_ / 100.)).append(" ");
    result.append(form == nvs::OutputFormString::LONG ? longName_ :
                  shortName_);
    result.append(", ");
    result.append(money::to_string(faceUp_, form));
    result += ']';

    return result;
}

// méthodes statiques

// implémentation de fonctions

std::ostream & operator<<(std::ostream & out, const Coin & coin)
{
    out << '[' << coin.value_ / 100. << ' ' << coin.shortName_ <<
        ", " << coin.faceUp_ << ']';
    return out;
}

} // namespace money
