/*!
 * \file coin.h
 * \brief Définition de la classe money::Coin et de fonctions
 *        utilisant ce type.
 */
#ifndef COIN_H
#define COIN_H

#include "../observer/subject.h"
#include "../misc/outputformstring.h"
#include "side.h"

#include <string>
#include <ostream>

/*!
 * \brief Espace de nom des pièces de monnaies et autres petites choses.
 */
namespace money
{

/*!
 * \brief Classe _abstraite_ représentant une pièce de monnaie.
 *
 * Une pièce de monnaie est caractérisée par~:
 *      + un nom de devise long ;
 *      + un nom de devise court ;
 *      + une valeur ;
 *      + une face visible.
 *
 * Les valeurs sont exprimées en centième de l'unité monétaire.
 * La classe Coin n'est donc adaptée qu'aux monaies ayant adapté le
 * système décimal, telles
 * l'[euro](https://fr.wikipedia.org/wiki/Pi%C3%A8ces_en_euro_destin%C3%A9es_%C3%A0_la_circulation#Description_des_pi.C3.A8ces),
 * le
 * [dollar américain](https://fr.wikipedia.org/wiki/Dollar_am%C3%A9ricain#Pi.C3.A8ces_et_billets),
 * le
 * [yen](https://fr.wikipedia.org/wiki/Yen#Pi.C3.A8ces_de_monnaie)
 * ou la
 * [livre sterling](https://fr.wikipedia.org/wiki/Pi%C3%A8ces_de_monnaie_en_livre_sterling#Usage).
 *
 */
class Coin : public nvs::Subject
{
    /*! \brief Le nom long de la devise de la pièce de monnaie. */
    const std::string longName_;

    /*! \brief Le nom court de la devise de la pièce de monnaie. */
    const std::string shortName_;

    /*! \brief La valeur de la pièce de monnaie exprimée en centième
     * de l'unité monétaire. */
    const unsigned value_;

    /*! \brief La face visible de la pièce de monnaie. */
    Side faceUp_ { Side::UNKNOWN };

    /*!
     * \brief Validation de la valeur.
     *
     * Méthode de validation de la valeur d'une pièce de monnaie.
     * Elle est virtuelle pure. Elle doit donc être implémentée
     * par chaque classe fille.
     * Elle doit en outre être _utilisée_ par le constructeur de la
     * classe fille. En effet, dans la classe Coin, elle n'existe pas
     * puisque c'est une méthode virtuelle pure. Davantage de détails
     * au sujet de l'appel de méthodes virtuelles dans un
     * constructeurs sont disponibles dans la
     * [C++ Super-FAQ]
     * (https://isocpp.org/wiki/faq/strange-inheritance#calling-virtuals-from-ctors).
     *
     * \param value la valeur à valider.
     *
     * \throw std::invalid_argument si `value` n'est pas valide.
     */
    virtual void validateValue(unsigned value) = 0;

  public:

    /*!
     * \brief Constructeur.
     *
     * À la construction, une pièce de monnaie présente toujours
     * une face inconnue.
     *
     * La valeur n'est pas validée. C'est au constructeur de la
     * classe dérivée de le faire car le constructeur de Coin
     * en est incapable : sa méthode validateValue() est virtuelle
     * pure.
     *
     * Les noms, long et court, ne sont quant à eux _jamais_ validés.
     *
     * \param longName le nom long de la devise.
     * \param shortName le nom court de la devise.
     * \param value la valeur initiale.
     *
     * \see validateValue().
     */
    inline Coin(const std::string & longName,
                const std::string & shortName,
                unsigned value);

    /*!
     * \brief Destructeur virtuel par défaut car utilisation
     *        polymorphique.
     */
    virtual ~Coin() = default;

    /*!
     * \brief Constructeur par recopie par défaut.
     *
     * Le destructeur virtuel par défaut a des effets en cascade.
     *
     * \sa nvs::Subject::Subject(const Subject &)
     */
    Coin(const Coin &) = default;

    /*!
     * \brief Constructeur par déplacement par défaut.
     *
     * Le destructeur virtuel par défaut a des effets en cascade.
     *
     * \sa nvs::Subject::Subject(Subject &&)
     */
    Coin(Coin &&) = default;

    /*!
     * \brief Opérateur d'assignation par recopie par défaut.
     *
     * Le destructeur virtuel par défaut a des effets en cascade.
     *
     * \sa nvs::Subject::operator=(const Subject &)
     */
    Coin & operator=(const Coin &) = default;

    /*!
     * \brief Opérateur d'assignation par déplacement par défaut.
     *
     * Le destructeur virtuel par défaut a des effets en cascade.
     *
     * \sa nvs::Subject::operator=(Subject &&)
     */
    Coin & operator=(Coin &&) = default;

    /*!
     * \brief Accesseur en lecture de l'état de la pièce de monnaie.
     *
     * \return l'état de la pièce de monnaie.
     */
    inline Side faceUp() const;

    /*!
     * \brief Accesseur en lecture de la valeur (en centimes)
     *        de la pièce de monnaie.
     *
     * \return la valeur de la pièce de monnaie.
     */
    inline unsigned value() const;

    /*!
     * \brief Accesseur en lecture du nom long de la devise
     *        de la pièce de monnaie.
     *
     * \return Le nom long de la devise de la pièce de monnaie.
     */
    inline std::string longName() const;

    /*!
     * \brief Accesseur en lecture du nom court de la devise
     *        de la pièce de monnaie.
     *
     * \return Le nom court de la devise de la pièce de monnaie.
     */
    inline std::string shortName() const;

    /*!
     * \brief Accesseur en écriture la face visible de la pièce de
     *        monnaie.
     *
     * Les observateurs enregistrés ne sont notifiés que si la
     * face visible change effectivement lors de l'appel de
     * setFaceUp().
     *
     * \param face la face visible désirée de la pièce de monnaie.
     */
    void setFaceUp(Side face);

    /*!
     * \brief Tirer à pile ou facer.
     *
     * Méthode pour tirer à pile ou face.
     *
     * Les observateurs enregistrés sont notifiés dans tous les
     * cas lors de l'appel de flip().
     *
     * \return la face visible après avoir tiré à pile ou face.
     */
    Side flip();

    /*!
     * \brief Conversion en chaîne de caractères.
     *
     * Méthode de conversion d'une pièce de monnaie en chaîne de
     * caractères.
     *
     * Cette méthode utilise les fonctions to_string de l'espace
     * de nom standard pour ce qui concerne la valeur de la
     * pièce de monnaie et de l'espace de nom `money` pour ce
     * qui concerne sa face visible. Le résultat obtenu
     * pour la valeur n'est pas identique à celui obtenu avec
     * l'opérateur d'injection dans un flux (voir la note et les
     * exemples
     * [ici](http://en.cppreference.com/w/cpp/string/basic_string/to_string)
     * pour plus de détails). Le nom de la devise est injectée sous
     * sa forme longue ou courte, selon la valeur de `form`.
     *
     * \param form pour contrôler la forme longue ou courte de
     *             l'affichage.
     *
     * \return une chaîne de caractères représentant la valeur
     *         (en unité) et la face visible de la pièce de monnaie.
     */
    std::string to_string(nvs::OutputFormString form =
                              nvs::OutputFormString::SHORT) const;

    // déclarations d'amitié

    friend std::ostream & operator<<(std::ostream & out,
                                     const Coin & coin);
};

// prototypes

/*!
 * \brief Opérateur d'injection dans un flux en sortie.
 *
 * La valeur de la pièce est représentée en unité monétaire
 * et non en centimes. Le nom de la devise est injecté sous sa forme
 * courte. La face visible est injectée sous sa
 * forme courte, comme produit par
 * operator<<(std::ostream &, money::Side).
 *
 * \param out le flux en sortie dans lequel l'injection a lieu.
 * \param coin la pièce de monnaie à injecter.
 *
 * \return le flux après l'injection.
 */
std::ostream & operator<<(std::ostream & out,
                          const Coin & coin);

/*!
 * \brief Conversion en chaîne de caractères.
 *
 * Fonction de conversion d'une pièce de monnaie en chaîne de
 * caractères.
 *
 * Cette fonction utilise la méthode Coin::to_string().
 *
 * \param coin la pièce de monnaie à convertir.
 * \param form pour contrôler la forme longue ou courte de
 *             l'affichage.
 *
 * \return une chaîne de caractères représentant la valeur
 *         et l'état de la pièce de monnaie.
 */
inline std::string to_string(const Coin & coin,
                             nvs::OutputFormString form =
                                 nvs::OutputFormString::SHORT);

// implémentation de méthodes inline

Coin::Coin(const std::string & longName,
           const std::string & shortName,
           unsigned value) :
    longName_ { longName }, shortName_ { shortName }, value_ { value }
{ }

Side Coin::faceUp() const
{
    return faceUp_;
}

unsigned Coin::value() const
{
    return value_;
}

std::string Coin::longName() const
{
    return longName_;
}

std::string Coin::shortName() const
{
    return shortName_;
}

// implémentation de fonctions inline

std::string to_string(const Coin & coin, nvs::OutputFormString form)
{
    return coin.to_string(form);
}

} // namespace money

#endif // COIN_H
