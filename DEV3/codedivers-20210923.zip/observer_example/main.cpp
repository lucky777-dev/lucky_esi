/*!
 * \file main.cpp
 * \brief Fichier où est implémenté le point d'entrée de l'exemple
 *        d'utilisation du design pattern Observer.
 */
#include "concreteobserver/consolecoinobserver.h"
#include "model/eurocoin.h"

#include <iostream>

/*!
 * \mainpage Observer Example : Coin and ConsoleCoinObserver.
 *
 * Illustrution du modèle de conception
 * [Observer](https://en.wikipedia.org/wiki/Observer_pattern).
 * L'implémentation de ce _desing pattern_
 * donnée ici est fidèle au modèle du
 * [Gang of Four](https://en.wikipedia.org/wiki/Design_Patterns). En
 * particulier, il n'y est pas fait usage d'une classe correspondant
 * aux _événements_, mais uniquement d'une classe
 * _source d'événements_, le sujet nvs::Subject, et d'une classe
 * _écouteur d'événements_, l'observateur nvs::Observer.
 *
 * Dans ses mises en œuvre effective, ce modèle est très souvent
 * étoffé par l'ajout de classes d'événement ou par la multiplication
 * des méthodes de notification.
 * Rien, cependant, de ce que ces complexifications du modèle
 * rendent plus facile aux utilisateurs, n'est hors de portée du
 * modèle simple donné ici. Les développements du modèle de conception
 * peuvent en effet être reportées sur les classes concrètes qui
 * l'implémentent. Remarquez que si le contenu de ce paragraphe
 * vous semble abscons, oubliez-le provisoirement. On en reparle
 * lors de la
 * [gestion des événements avec Qt](https://doc.qt.io/qt-5/eventsandfilters.html).
 *
 * Notez également que la classe métier money::Coin est directement
 * un nvs::Subject. Une découpe plus rigoureuse du problème
 * pourrait consister à développer une classe CoinSubject qui
 * dériverait à la fois de nvs::Subject et de money::Coin, où cette
 * denière ne serait _pas_ un nvs::Subject, et donc ne notifierait
 * rien ni personne lors de la modification de sa face visible.
 *
 */

/*!
 * \brief Fonction principale.
 *
 * Ppoint d'entrée de l'exemple d'utilisation du _design pattern_
 * Observer.
 *
 * \return 0 car tout se passe toujours bien ;-)
 */
int main()
{
    using namespace std;
    using namespace money;

    EuroCoin coin;
    cout << coin << endl;

    {
        ConsoleCoinObserver cco { &coin };

        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::TAIL);
        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::HEAD);
        coin.setFaceUp(Side::HEAD);

        cout << "\npile ou face : " << endl;
        for (unsigned u { 0 }; u < 6; ++u)
        {
            coin.flip();
        }
        cout << endl;
    }   // cco détruit ici

    cout << "observateur détruit : ";
    coin.flip();
    cout << "rien" << endl;
    // boum si ConsoleCoinObserver ne se désinscrit pas
    // lors de sa destruction
}
