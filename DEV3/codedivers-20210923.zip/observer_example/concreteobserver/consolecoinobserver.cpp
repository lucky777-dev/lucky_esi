/*!
 * \file consolecoinobserver.cpp
 * \brief Implémentation de la classe money::ConsoleCoinObserver.
 */
#include "consolecoinobserver.h"
#include "../model/coin.h"

#include <iostream>

namespace money
{

ConsoleCoinObserver::ConsoleCoinObserver(Coin * subject) :
    subject_ { subject }
{
    subject_->registerObserver(this);
    update(subject_);
}

ConsoleCoinObserver::~ConsoleCoinObserver()
{
    subject_->unregisterObserver(this);   // essayer sans...
}

void ConsoleCoinObserver::update(const nvs::Subject * subject)
{
    if (subject != subject_) return;

    std::cout << "[cco] : " << *subject_ << std::endl;
}

} // namespace money
