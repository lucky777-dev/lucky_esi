/*!
 * \file consolecoinobserver.h
 * \brief Définition de la classe money::ConsoleCoinObserver.
 */
#ifndef CONSOLECOINOBSERVER_H
#define CONSOLECOINOBSERVER_H

#include "../observer/observer.h"

/*!
 * \brief Espace de nom des pièces de monnaies et autres petites choses.
 */
namespace money
{

class Coin;

/*!
 * \brief Observateur console de money::Coin.
 *
 * Cette classe implémente concrètement le classe abstraite
 * nvs::Observer. Ses instances s'attachent à une et une seule
 * pièce de monnaie. Elles se contentent d'injecter leur sujet
 * d'observation, le money::Coin qu'elles observent, dans le
 * flux en sortie standard std::cout.
 */
class ConsoleCoinObserver final : public nvs::Observer
{
    /*! \brief Le sujet observé. */
    Coin * subject_;

  public:

    /*!
     * \brief Constructeur.
     *
     * Le constructeur attache l'observateur en cours de construction
     * à la money::Coin fournie en argument. En fin de constructon,
     * l'observateur se met à jour.
     *
     * \param subject L'adresse de la pièce de monnaie observée.
     */
    ConsoleCoinObserver(Coin * subject);

    /*!
     * \brief Destructeur.
     *
     * Lors de le destruction de l'observateur, il doit se détacher
     * de son sujet d'observation.
     */
    virtual ~ConsoleCoinObserver();

    /*!
     * \brief Mise à jour de l'observateur.
     *
     * Si subject est bien l'adresse de la pièce de monnaie
     * observée, l'observateur injecte celle-ci dans le flux
     * associé à la sortie standard, sinon, il ne se passe rien.
     *
     * \param subject Le nvs::Subject qui notifie un changement
     *                d'état.
     */
    virtual void update(const nvs::Subject * subject) override;
};

} // namespace money

#endif // CONSOLECOINOBSERVER_H
