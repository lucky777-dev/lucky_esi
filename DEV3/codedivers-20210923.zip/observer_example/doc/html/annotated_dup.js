var annotated_dup =
[
    [ "money", "namespacemoney.html", "namespacemoney" ],
    [ "nvs", "namespacenvs.html", "namespacenvs" ]
];