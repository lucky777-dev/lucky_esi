var NAVTREE =
[
  [ "Observer Example : Coin and ConsoleCoinObserver.", "index.html", [
    [ "Espaces de nommage", null, [
      [ "Liste des espaces de nommage", "namespaces.html", "namespaces" ],
      [ "Membres de l'espace de nommage", "namespacemembers.html", [
        [ "Tout", "namespacemembers.html", null ],
        [ "Fonctions", "namespacemembers_func.html", null ],
        [ "Énumérations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Liste des classes", "annotated.html", "annotated_dup" ],
      [ "Index des classes", "classes.html", null ],
      [ "Hiérarchie des classes", "hierarchy.html", "hierarchy" ],
      [ "Membres de classe", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Fonctions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Fonctions associées", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ],
      [ "Membres de fichier", "globals.html", [
        [ "Tout", "globals.html", null ],
        [ "Fonctions", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';