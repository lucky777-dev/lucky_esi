var classnvs_1_1_observer =
[
    [ "~Observer", "classnvs_1_1_observer.html#aad2df366134bc340a8717360cd7307d2", null ],
    [ "Observer", "classnvs_1_1_observer.html#a4515f485c0ca822e088cffdfc30d3ed8", null ],
    [ "Observer", "classnvs_1_1_observer.html#a3058c1a0d319e92a563a6ed09354e8f6", null ],
    [ "Observer", "classnvs_1_1_observer.html#a755ac6084a75b80cf8b7a7cf6fd4e8dd", null ],
    [ "operator=", "classnvs_1_1_observer.html#a405218b4689360fb9d8fdab3bed37dad", null ],
    [ "operator=", "classnvs_1_1_observer.html#a12803c6d97f98c355a0f46b36a35d64b", null ],
    [ "update", "classnvs_1_1_observer.html#a4c0373c644180bdc48558e5248968b3a", null ]
];