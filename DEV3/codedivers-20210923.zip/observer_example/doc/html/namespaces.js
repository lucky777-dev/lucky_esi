var namespaces =
[
    [ "money", "namespacemoney.html", null ],
    [ "nvs", "namespacenvs.html", null ]
];