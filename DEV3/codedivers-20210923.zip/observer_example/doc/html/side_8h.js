var side_8h =
[
    [ "Side", "side_8h.html#a8176ab960f63bb7aee87eabde92e6b15", [
      [ "UNKNOWN", "side_8h.html#a8176ab960f63bb7aee87eabde92e6b15a696b031073e74bf2cb98e5ef201d4aa3", null ],
      [ "HEAD", "side_8h.html#a8176ab960f63bb7aee87eabde92e6b15ae15e216fc1c639f787b1231ecdfa1bf8", null ],
      [ "TAIL", "side_8h.html#a8176ab960f63bb7aee87eabde92e6b15a026ba6d3d7dd81197fee244bb8c7fc6d", null ]
    ] ],
    [ "operator<<", "side_8h.html#a8aff5669bb2b83e3511c559b9b59b4e3", null ],
    [ "to_string", "side_8h.html#ac75a290fc90273414a8313bf91136cc2", null ]
];