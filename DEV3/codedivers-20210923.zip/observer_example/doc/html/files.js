var files =
[
    [ "coin.cpp", "coin_8cpp.html", "coin_8cpp" ],
    [ "coin.h", "coin_8h.html", "coin_8h" ],
    [ "consolecoinobserver.cpp", "consolecoinobserver_8cpp.html", null ],
    [ "consolecoinobserver.h", "consolecoinobserver_8h.html", [
      [ "ConsoleCoinObserver", "classmoney_1_1_console_coin_observer.html", "classmoney_1_1_console_coin_observer" ]
    ] ],
    [ "eurocoin.cpp", "eurocoin_8cpp.html", null ],
    [ "eurocoin.h", "eurocoin_8h.html", [
      [ "EuroCoin", "classmoney_1_1_euro_coin.html", "classmoney_1_1_euro_coin" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "observer.h", "observer_8h.html", [
      [ "Observer", "classnvs_1_1_observer.html", "classnvs_1_1_observer" ]
    ] ],
    [ "outputformstring.h", "outputformstring_8h.html", "outputformstring_8h" ],
    [ "randomgenerator.hpp", "randomgenerator_8hpp.html", "randomgenerator_8hpp" ],
    [ "side.cpp", "side_8cpp.html", "side_8cpp" ],
    [ "side.h", "side_8h.html", "side_8h" ],
    [ "subject.cpp", "subject_8cpp.html", null ],
    [ "subject.h", "subject_8h.html", [
      [ "Subject", "classnvs_1_1_subject.html", "classnvs_1_1_subject" ]
    ] ]
];