var coin_8h =
[
    [ "Coin", "classmoney_1_1_coin.html", "classmoney_1_1_coin" ],
    [ "operator<<", "coin_8h.html#a4fa60f0dc756830aa658a1b8a727f771", null ],
    [ "to_string", "coin_8h.html#a9dca143800ae6bcd44fd50d5c891f6a4", null ]
];