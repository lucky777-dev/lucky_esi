var namespacenvs =
[
    [ "Observer", "classnvs_1_1_observer.html", "classnvs_1_1_observer" ],
    [ "Subject", "classnvs_1_1_subject.html", "classnvs_1_1_subject" ]
];