var namespacemoney =
[
    [ "Coin", "classmoney_1_1_coin.html", "classmoney_1_1_coin" ],
    [ "ConsoleCoinObserver", "classmoney_1_1_console_coin_observer.html", "classmoney_1_1_console_coin_observer" ],
    [ "EuroCoin", "classmoney_1_1_euro_coin.html", "classmoney_1_1_euro_coin" ]
];