var coin_8cpp =
[
    [ "operator<<", "coin_8cpp.html#a4fa60f0dc756830aa658a1b8a727f771", null ]
];