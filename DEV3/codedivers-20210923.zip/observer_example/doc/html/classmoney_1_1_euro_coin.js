var classmoney_1_1_euro_coin =
[
    [ "EuroCoin", "classmoney_1_1_euro_coin.html#a4197e220416ee8468fcf5633d41f5d2e", null ],
    [ "validateValue", "classmoney_1_1_euro_coin.html#a5c03186a9c849fb202b2382bb371d3f1", null ]
];