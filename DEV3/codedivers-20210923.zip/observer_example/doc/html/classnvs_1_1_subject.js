var classnvs_1_1_subject =
[
    [ "~Subject", "classnvs_1_1_subject.html#ae6c2083563615d4f449f55b970835816", null ],
    [ "Subject", "classnvs_1_1_subject.html#acb8bf74c98c8ec96d999ce98cd3fab22", null ],
    [ "Subject", "classnvs_1_1_subject.html#a228776e466dd330075d3f4a089c006f4", null ],
    [ "Subject", "classnvs_1_1_subject.html#a698aabcd0083be40995673ba4d887487", null ],
    [ "notifyObservers", "classnvs_1_1_subject.html#ad83249e4bf32876918f93a8f6a54bfac", null ],
    [ "operator=", "classnvs_1_1_subject.html#aba16a1e0481f97b74a66468dab1d50bf", null ],
    [ "operator=", "classnvs_1_1_subject.html#afa3849e579c73fc54258f2b5ddd8317e", null ],
    [ "registerObserver", "classnvs_1_1_subject.html#a4a476a25d1fa0db77f5ca86a6b0637f2", null ],
    [ "unregisterObserver", "classnvs_1_1_subject.html#a749bc5b9a58ba0f72abbbce0f01f8a24", null ],
    [ "observers_", "classnvs_1_1_subject.html#a71448bb8a51b098168d010dfe854450c", null ]
];