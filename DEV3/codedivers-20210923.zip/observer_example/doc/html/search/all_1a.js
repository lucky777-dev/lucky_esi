var searchData=
[
  ['zero',['zero',['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::minutes::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::seconds::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::duration::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::milliseconds::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::hours::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration_values/zero.html',1,'std::chrono::duration_values::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::microseconds::zero()'],['http://en.cppreference.com/w/cpp/chrono/duration/zero.html',1,'std::chrono::nanoseconds::zero()']]],
  ['zetta',['zetta',['http://en.cppreference.com/w/cpp/numeric/ratio/ratio.html',1,'std']]]
];
