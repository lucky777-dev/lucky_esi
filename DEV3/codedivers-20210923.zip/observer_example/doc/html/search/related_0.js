var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classmoney_1_1_coin.html#a8b4e7655a97d8acbb60036adbf3a32f0',1,'money::Coin']]]
];
