var searchData=
[
  ['observer_20example_20_3a_20coin_20and_20consolecoinobserver_2e',['Observer Example : Coin and ConsoleCoinObserver.',['../index.html',1,'']]]
];
