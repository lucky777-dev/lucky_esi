var searchData=
[
  ['long',['LONG',['../namespacenvs.html#a139c62549fc7de541617d1934caf3a41ac1fabfea54ec6011e694f211f3ffebf3',1,'nvs']]]
];
