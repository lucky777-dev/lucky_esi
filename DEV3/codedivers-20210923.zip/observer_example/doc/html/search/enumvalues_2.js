var searchData=
[
  ['short',['SHORT',['../namespacenvs.html#a139c62549fc7de541617d1934caf3a41aa35c2b02966b1563e5bf7b81b8b0cf77',1,'nvs']]]
];
