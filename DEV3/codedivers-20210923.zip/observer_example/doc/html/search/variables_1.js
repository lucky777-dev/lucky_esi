var searchData=
[
  ['longname_5f',['longName_',['../classmoney_1_1_coin.html#a9556752dccdc697db46f856e632d923b',1,'money::Coin']]]
];
