var searchData=
[
  ['join',['join',['http://en.cppreference.com/w/cpp/thread/thread/join.html',1,'std::thread']]],
  ['joinable',['joinable',['http://en.cppreference.com/w/cpp/thread/thread/joinable.html',1,'std::thread']]]
];
