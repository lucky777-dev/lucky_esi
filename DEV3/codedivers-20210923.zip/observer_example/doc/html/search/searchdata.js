var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnopqrstuvwyz",
  2: "mns",
  3: "cemors",
  4: "_abcdefghijklmnopqrstuvwxyz~",
  5: "flosv",
  6: "os",
  7: "hlstu",
  8: "o",
  9: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Amis",
  9: "Pages"
};

