var searchData=
[
  ['observers_5f',['observers_',['../classnvs_1_1_subject.html#a71448bb8a51b098168d010dfe854450c',1,'nvs::Subject']]]
];
