var searchData=
[
  ['shortname_5f',['shortName_',['../classmoney_1_1_coin.html#a287b307f90e43fafb5742a40f2531d21',1,'money::Coin']]],
  ['subject_5f',['subject_',['../classmoney_1_1_console_coin_observer.html#aa2da5eb875fb026546e2205f57f613ed',1,'money::ConsoleCoinObserver']]]
];
