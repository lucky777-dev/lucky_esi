var searchData=
[
  ['value_5f',['value_',['../classmoney_1_1_coin.html#a08ed059b4844503a732f470c26a97b49',1,'money::Coin']]]
];
