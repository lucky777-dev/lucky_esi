var hierarchy =
[
    [ "nvs::Observer", "classnvs_1_1_observer.html", [
      [ "money::ConsoleCoinObserver", "classmoney_1_1_console_coin_observer.html", null ]
    ] ],
    [ "nvs::Subject", "classnvs_1_1_subject.html", [
      [ "money::Coin", "classmoney_1_1_coin.html", [
        [ "money::EuroCoin", "classmoney_1_1_euro_coin.html", null ]
      ] ]
    ] ]
];