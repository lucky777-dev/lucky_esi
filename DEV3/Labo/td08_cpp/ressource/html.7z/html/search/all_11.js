var searchData=
[
  ['qsort',['qsort',['http://en.cppreference.com/w/cpp/algorithm/qsort.html',1,'std']]],
  ['queue',['queue',['http://en.cppreference.com/w/cpp/container/queue.html',1,'std::queue'],['http://en.cppreference.com/w/cpp/container/queue/queue.html',1,'std::queue::queue()']]],
  ['quick_5fexit',['quick_exit',['http://en.cppreference.com/w/cpp/utility/program/quick_exit.html',1,'std']]],
  ['quiet_5fnan',['quiet_NaN',['http://en.cppreference.com/w/cpp/types/numeric_limits/quiet_NaN.html',1,'std::numeric_limits']]]
];
