var searchData=
[
  ['zetta',['zetta',['http://en.cppreference.com/w/cpp/numeric/ratio/ratio.html',1,'std']]]
];
