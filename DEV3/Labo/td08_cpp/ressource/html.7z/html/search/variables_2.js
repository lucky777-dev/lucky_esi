var searchData=
[
  ['sign_5f',['sign_',['../classnvs_1_1_fraction.html#ad3f8f50ee023360950c45151bcba0710',1,'nvs::Fraction']]]
];
