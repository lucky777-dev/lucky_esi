var searchData=
[
  ['numerator_5f',['numerator_',['../classnvs_1_1_fraction.html#a2a3c3004ec93b5dead494d5907a749c2',1,'nvs::Fraction']]]
];
