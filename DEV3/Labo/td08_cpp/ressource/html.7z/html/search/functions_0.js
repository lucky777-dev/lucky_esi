var searchData=
[
  ['_5fexit',['_Exit',['http://en.cppreference.com/w/cpp/utility/program/_Exit.html',1,'std']]]
];
