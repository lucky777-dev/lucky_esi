var searchData=
[
  ['minus',['MINUS',['../namespacenvs.html#ad09dcc513fb50fc13bc5846bcf00940caffc0d9b54a1fe677c4c9e6b050e67c81',1,'nvs']]]
];
