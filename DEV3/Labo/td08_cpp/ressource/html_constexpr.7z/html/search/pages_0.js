var searchData=
[
  ['fraction_20_28constexpr_29',['Fraction (constexpr)',['../index.html',1,'']]]
];
