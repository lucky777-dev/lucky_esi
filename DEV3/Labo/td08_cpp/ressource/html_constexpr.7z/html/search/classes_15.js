var searchData=
[
  ['va_5flist',['va_list',['http://en.cppreference.com/w/cpp/utility/variadic/va_list.html',1,'']]],
  ['valarray',['valarray',['http://en.cppreference.com/w/cpp/numeric/valarray.html',1,'std']]],
  ['value_5fcompare',['value_compare',['http://en.cppreference.com/w/cpp/container/map/value_compare.html',1,'std::map::value_compare'],['http://en.cppreference.com/w/cpp/container/multimap/value_compare.html',1,'std::multimap::value_compare']]],
  ['vector',['vector',['http://en.cppreference.com/w/cpp/container/vector.html',1,'std']]]
];
