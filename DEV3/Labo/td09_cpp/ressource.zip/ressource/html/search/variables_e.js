var searchData=
[
  ['second',['second',['http://en.cppreference.com/w/cpp/utility/pair.html',1,'std::pair']]]
];
