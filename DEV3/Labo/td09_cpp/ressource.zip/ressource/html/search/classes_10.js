var searchData=
[
  ['queue',['queue',['http://en.cppreference.com/w/cpp/container/queue.html',1,'std']]]
];
