var searchData=
[
  ['exception',['exception',['http://en.cppreference.com/w/cpp/header/exception.html',1,'']]],
  ['execution',['execution',['http://en.cppreference.com/w/cpp/header/execution.html',1,'']]]
];
