var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnopqrstuvwyz",
  2: "ns",
  3: "abcdefilmnopqrstuv",
  4: "_abcdefghijklmnopqrstuvwxyz~",
  5: "acdefhilmnopqrstuv",
  6: "e",
  7: "is",
  8: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Pages"
};

