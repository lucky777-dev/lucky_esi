var searchData=
[
  ['extent_5fv',['extent_v',['http://en.cppreference.com/w/cpp/types/extent.html',1,'std::extent_v()'],['http://en.cppreference.com/w/cpp/experimental/type_trait_variable_templates.html',1,'std::experimental::extent_v()']]]
];
