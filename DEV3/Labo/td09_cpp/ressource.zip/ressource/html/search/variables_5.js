var searchData=
[
  ['has_5funique_5fobject_5frepresentations_5fv',['has_unique_object_representations_v',['http://en.cppreference.com/w/cpp/types/has_unique_object_representations.html',1,'std']]],
  ['has_5fvirtual_5fdestructor_5fv',['has_virtual_destructor_v',['http://en.cppreference.com/w/cpp/types/has_virtual_destructor.html',1,'std::has_virtual_destructor_v()'],['http://en.cppreference.com/w/cpp/experimental/type_trait_variable_templates.html',1,'std::experimental::has_virtual_destructor_v()']]]
];
