var searchData=
[
  ['quot',['quot',['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::div_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::imaxdiv_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::ldiv_t::quot()'],['http://en.cppreference.com/w/cpp/numeric/math/div.html',1,'std::lldiv_t::quot()']]]
];
