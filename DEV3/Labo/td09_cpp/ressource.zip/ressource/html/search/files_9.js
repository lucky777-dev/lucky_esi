var searchData=
[
  ['new',['new',['http://en.cppreference.com/w/cpp/header/new.html',1,'']]],
  ['numeric',['numeric',['http://en.cppreference.com/w/cpp/header/numeric.html',1,'']]]
];
