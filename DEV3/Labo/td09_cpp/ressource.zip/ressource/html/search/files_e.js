var searchData=
[
  ['scoped_5fallocator',['scoped_allocator',['http://en.cppreference.com/w/cpp/header/scoped_allocator.html',1,'']]],
  ['set',['set',['http://en.cppreference.com/w/cpp/header/set.html',1,'']]],
  ['shared_5fmutex',['shared_mutex',['http://en.cppreference.com/w/cpp/header/shared_mutex.html',1,'']]],
  ['span',['span',['http://en.cppreference.com/w/cpp/header/span.html',1,'']]],
  ['sstream',['sstream',['http://en.cppreference.com/w/cpp/header/sstream.html',1,'']]],
  ['stack',['stack',['http://en.cppreference.com/w/cpp/header/stack.html',1,'']]],
  ['stdexcept',['stdexcept',['http://en.cppreference.com/w/cpp/header/stdexcept.html',1,'']]],
  ['streambuf',['streambuf',['http://en.cppreference.com/w/cpp/header/streambuf.html',1,'']]],
  ['string',['string',['http://en.cppreference.com/w/cpp/header/string.html',1,'']]],
  ['string_5fview',['string_view',['http://en.cppreference.com/w/cpp/header/string_view.html',1,'']]],
  ['strstream',['strstream',['http://en.cppreference.com/w/cpp/header/strstream.html',1,'']]],
  ['syncstream',['syncstream',['http://en.cppreference.com/w/cpp/header/syncstream.html',1,'']]],
  ['system_5ferror',['system_error',['http://en.cppreference.com/w/cpp/header/system_error.html',1,'']]]
];
