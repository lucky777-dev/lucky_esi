var searchData=
[
  ['registerobserver',['registerObserver',['../classArraySubject.html#ac45f0da1387eb1dea691637dd8ef6fb0',1,'ArraySubject']]]
];
