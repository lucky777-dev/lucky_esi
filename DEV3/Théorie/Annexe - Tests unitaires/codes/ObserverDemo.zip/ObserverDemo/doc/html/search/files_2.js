var searchData=
[
  ['printingobserver_2ehpp',['printingobserver.hpp',['../printingobserver_8hpp.html',1,'']]]
];
