var searchData=
[
  ['basicarrayevent',['BasicArrayEvent',['../classBasicArrayEvent.html',1,'BasicArrayEvent&lt; T &gt;'],['../classBasicArrayEvent.html#a5a286b0bd924988fe315180db43eb078',1,'BasicArrayEvent::BasicArrayEvent()']]]
];
