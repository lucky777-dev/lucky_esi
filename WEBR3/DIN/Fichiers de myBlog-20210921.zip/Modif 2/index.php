<?php
//Récupération des variables du modèle
require "Model.php";
$billets = getAllPosts();

//Affichage
require "vueAccueil.php";
