<?php
require "Model.php";
class Post extends Model {
    function getAllPosts() {
        $sql = 'select BIL_ID as id, BIL_DATE as date,'
        . ' BIL_TITRE as titre, BIL_CONTENU as contenu from T_BILLET'
        . ' order by BIL_ID desc';
        $this->executeRequest($sql);
    }
}
