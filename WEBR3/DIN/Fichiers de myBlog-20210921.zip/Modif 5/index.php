<?php
try {
    require "Post.php";
    $post = new Post();
    $billets = $post->getAllPosts();
    require "vueAccueil.php";
} catch (PDOException $e) {
    require "ViewError.php";
}