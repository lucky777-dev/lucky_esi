<?php
//Récupération des variables du modèle
require "Model.php";

//Affichage
require "vueAccueil.php";
