<?php
require "Post.php";

function allPosts() {
    $post = new Post();
    $billets = $post->getAllPosts();
    require "vueAccueil.php";
}