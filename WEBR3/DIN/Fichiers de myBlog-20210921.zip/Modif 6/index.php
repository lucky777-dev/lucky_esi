<?php
require "Router.php";
routeRequest();