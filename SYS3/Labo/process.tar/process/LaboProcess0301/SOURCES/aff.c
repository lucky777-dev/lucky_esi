/*
NOM    	: aff.c
CLASSE 	: Process - LaboProcess 03-01
#OBJET  : réservé au Makefile 
AUTEUR	: J.C. Jaumain, 07/2011
*/
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char * argv[])
{	printf("%s\n",argv[1]);
	exit(0); 
}
