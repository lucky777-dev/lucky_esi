/*
 NOM 	: boucle.h
 CLASSE : intro - LaboIntro  01-02
 AUTEUR : MBA
 DATE	: 01/2016
*/

void onBoucle (char *texte, int compt);

