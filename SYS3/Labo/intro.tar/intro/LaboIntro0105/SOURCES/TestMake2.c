/*
NOM    	: TestMake2.c
CLASSE 	: Intro - LaboIntro  01-01
#OBJET  : réservé au makefile
AUTEUR	: mba 01/2016
*/
#include <stdlib.h>
#include <stdio.h>
#include "TestMake2.h"
#include "monInclude.h"
int main (){
   printf("MAX=%d\n",MAX);
   printf("MIN=%d\n",MIN);
   exit(0);
}
