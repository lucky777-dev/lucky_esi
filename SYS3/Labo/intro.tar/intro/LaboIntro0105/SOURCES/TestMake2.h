/*	
  NOM    : TestMake2.h
  AUTEUR : MBA
  DATE   : 01/2016
*/

#define MIN 5
