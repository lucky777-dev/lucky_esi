/*
NOM    	: TestMake.c
CLASSE 	: intro - LaboIntro  01-01
#OBJET  : réservé au makefile
AUTEUR	: mba 01/2016
*/
#include <stdlib.h>
#include <stdio.h>
#include "MonInclude.h"
int main ( int argc, char * argv[] )
{  
   printf("%d, %o, %X\n",MAX,MAX,MAX);
	// afficher MAX en base 10, 8 et 16 
   	// man format pour les spécifications de conversion de printf
   exit(0);
}
